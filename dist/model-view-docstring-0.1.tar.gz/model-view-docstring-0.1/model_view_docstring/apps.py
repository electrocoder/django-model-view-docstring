from django.apps import AppConfig


class ModelViewDocstringConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'model_view_docstring'
